# Glass Original Launcher (Android car player)

Starter Android Studio project for a landscape glass-style car launcher.

## Features
- Home/launcher activity (`HOME` intent filter)
- Responsive landscape layout
- Live digital clock and date
- Navigation intent shortcut
- Phone dialer and Android settings shortcuts
- Installed-app browser
- Glass-inspired translucent panels

## Build APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Select Build > Build APK(s).
4. APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.
5. Install on the head unit and choose **Glass Original** as the Home app if Android asks.

## Notes
- `minSdk 26` (Android 8.0+) in this starter.
- The UI is a functional starter, not a pixel-perfect reproduction of the concept image.
- Actual weather, vehicle speed/CAN data, radio controls, and Bluetooth state need device-specific integration.
- On Android 11+, package visibility rules and head-unit vendor customizations may affect app discovery/launching.

## Harry Potter + Bezza theme
The starter UI uses a midnight-blue, burgundy, and gold palette with Hogwarts-inspired labels and Bezza branding. A concept-art preview is included as `HarryPotter-Bezza-Launcher-Preview.png`.
The preview is a visual mockup; it is not automatically installed as the launcher background. The app itself is a starter project and may need device-specific adjustments.
