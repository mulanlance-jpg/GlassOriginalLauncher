package com.glassoriginal.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        setContent { GlassHome() }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .background(
                Brush.linearGradient(
                    listOf(Color(0xC01C263A), Color(0x99432F3A), Color(0x80301D2A))
                ),
                RoundedCornerShape(26.dp)
            )
            .padding(18.dp),
        content = content
    )
}

@Composable
fun GlassHome() {
    val context = LocalContext.current
    var clock by remember { mutableStateOf(Date()) }
    var showApps by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(listOf<android.content.pm.ApplicationInfo>()) }

    LaunchedEffect(Unit) {
        while (true) {
            clock = Date()
            delay(1000)
        }
    }
    LaunchedEffect(showApps) {
        if (showApps) {
            apps = context.packageManager.getInstalledApplications(0)
                .filter { context.packageManager.getLaunchIntentForPackage(it.packageName) != null }
                .sortedBy { context.packageManager.getApplicationLabel(it).toString().lowercase() }
        }
    }

    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(clock)
    val date = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(clock)

    BoxWithConstraints(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF080F20), Color(0xFF172943), Color(0xFF120D1C)))
        )
    ) {
        Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            GlassCard(Modifier.width(maxWidth * 0.13f).fillMaxHeight()) {
                listOf(Icons.Default.Home, Icons.Default.Navigation, Icons.Default.MusicNote,
                    Icons.Default.Phone, Icons.Default.Settings).forEachIndexed { index, icon ->
                    IconButton(onClick = {
                        when (index) {
                            1 -> launchByIntent(context, Intent(Intent.ACTION_VIEW, android.net.Uri.parse("google.navigation:q=")))
                            2 -> launchFirst(context, listOf("music", "spotify", "youtube.music"))
                            3 -> launchByIntent(context, Intent(Intent.ACTION_DIAL))
                            4 -> launchByIntent(context, Intent(android.provider.Settings.ACTION_SETTINGS))
                        }
                    }, modifier = Modifier.fillMaxWidth().weight(1f)) {
                        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    GlassCard(Modifier.weight(1.35f).fillMaxHeight()) {
                        Text(time, color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Light)
                        Text(date, color = Color(0xFFE0E6F0), fontSize = 17.sp)
                        Spacer(Modifier.height(16.dp))
                        Text("HOGWARTS  •  BEZZA", color = Color(0xFFFFD27A), fontSize = 12.sp, letterSpacing = 2.sp)
                    }
                    GlassCard(Modifier.weight(0.8f).fillMaxHeight()) {
                        Text("DRIVE", color = Color(0xFFE5D8C8), fontSize = 13.sp, letterSpacing = 3.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("BEZZA", color = Color(0xFFFFD27A), fontSize = 34.sp, fontWeight = FontWeight.Medium)
                        Text("A magical journey awaits", color = Color(0xFFE5D8C8), fontSize = 14.sp)
                    }
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    GlassCard(Modifier.weight(1f).fillMaxHeight()) {
                        Icon(Icons.Default.MusicNote, null, tint = Color(0xFFFFD27A), modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Music", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text("Hogwarts soundtrack", color = Color(0xFFE5D8C8), fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { launchFirst(context, listOf("music", "spotify", "youtube.music")) }) { Text("Open") }
                    }
                    GlassCard(Modifier.weight(1f).fillMaxHeight()) {
                        Icon(Icons.Default.Map, null, tint = Color(0xFFFFD27A), modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Navigation", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text("Find your next adventure", color = Color(0xFFE5D8C8), fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { launchByIntent(context, Intent(Intent.ACTION_VIEW, android.net.Uri.parse("google.navigation:q="))) }) { Text("Navigate") }
                    }
                    GlassCard(Modifier.weight(0.85f).fillMaxHeight()) {
                        Icon(Icons.Default.Apps, null, tint = Color(0xFFFFD27A), modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Apps", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text("All installed apps", color = Color(0xFFE5D8C8), fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { showApps = !showApps }) { Text(if (showApps) "Close" else "Browse") }
                    }
                }
            }
        }

        if (showApps) {
            Surface(
                modifier = Modifier.fillMaxSize().padding(28.dp),
                color = Color(0xF01A2435),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Installed apps", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { showApps = false }) { Text("Close") }
                    }
                    LazyVerticalGrid(columns = GridCells.Adaptive(130.dp), contentPadding = PaddingValues(8.dp)) {
                        items(apps) { app ->
                            Column(
                                Modifier.padding(8.dp).background(Color(0x663C4B61), RoundedCornerShape(16.dp))
                                    .clickable {
                                        context.packageManager.getLaunchIntentForPackage(app.packageName)?.let {
                                            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            context.startActivity(it)
                                        }
                                    }.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                androidx.compose.ui.viewinterop.AndroidView(
                                    factory = { android.widget.ImageView(it).apply {
                                        setImageDrawable(context.packageManager.getApplicationIcon(app))
                                    } },
                                    modifier = Modifier.size(42.dp)
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(context.packageManager.getApplicationLabel(app).toString(),
                                    color = Color.White, fontSize = 13.sp, maxLines = 2)
                            }
                        }
                    }
                }
            }
        }
    }
}

fun launchByIntent(context: android.content.Context, intent: Intent) {
    try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (_: Exception) { }
}

fun launchFirst(context: android.content.Context, terms: List<String>) {
    val pm = context.packageManager
    val candidates = pm.getInstalledApplications(0)
    val app = candidates.firstOrNull { info ->
        val label = pm.getApplicationLabel(info).toString().lowercase()
        terms.any { label.contains(it.replace(".", " ")) || info.packageName.lowercase().contains(it) }
    }
    app?.let { pm.getLaunchIntentForPackage(it.packageName)?.let { intent -> launchByIntent(context, intent) } }
}
